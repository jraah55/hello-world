functions.add('pi-anon', function() {
    return Math.PI;
});

functions.add('pi', function() {
    return less.Dimension(Math.PI);
});