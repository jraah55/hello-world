functions.addMultiple({
    "test-parse-error" : function() {