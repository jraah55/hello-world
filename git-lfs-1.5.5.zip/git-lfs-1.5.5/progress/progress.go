// Package progress provides common progress monitoring / display features
// NOTE: Subject to change, do not rely on this package from outside git-lfs source
package progress
