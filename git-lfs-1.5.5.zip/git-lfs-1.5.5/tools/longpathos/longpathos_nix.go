// +build !windows

package longpathos

func fixLongPath(path string) string {
	return path
}
