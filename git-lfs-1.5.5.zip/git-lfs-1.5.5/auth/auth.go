// Package auth provides common authentication tools
// NOTE: Subject to change, do not rely on this package from outside git-lfs source
package auth
