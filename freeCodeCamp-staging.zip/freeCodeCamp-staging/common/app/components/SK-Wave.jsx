import React, { PureComponent } from 'react';

const propTypes = {
};
export default class SKWave extends PureComponent {
  render() {
    return (
      <div className='sk-wave'>
        <div />
        <div />
        <div />
        <div />
        <div />
      </div>
    );
  }
}
SKWave.displayName = 'SKWave';
SKWave.propTypes = propTypes;
